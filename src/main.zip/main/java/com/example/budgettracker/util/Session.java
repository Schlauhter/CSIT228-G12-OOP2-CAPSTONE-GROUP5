package com.example.budgettracker.util;

import model.User;

/**
 * Session - holds the currently logged-in user throughout the app session.
 */
public class Session {
    private static User currentUser = null;

    public static void setCurrentUser(User user) {
        currentUser = user;
    }

    public static User getCurrentUser() {
        return currentUser;
    }

    public static int getCurrentUserId() {
        return (currentUser != null) ? currentUser.getUserId() : -1;
    }

    public static void logout() {
        currentUser = null;
    }
}
